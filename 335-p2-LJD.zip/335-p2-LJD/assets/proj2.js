// JavaScript source code
var max_1 = 16;
var max_2 = 8;
var max_3 = 7;

function num_causeways(num_causeways_prev, num_causeways_new)//used to create cleaner cannvas lines
{
    this.num_causeways_prev = num_causeways_prev;
    this.num_causeways_new = num_causeways_new;
}

function my_str_cmp(str_1, str_2)
{
    return str_1.localeCompare(str_2);
}
function char_to_int(my_char, my_value)//changes the char value to int including A-G values
{
    if (my_char <= 71 && my_char >= 65) {
        switch (my_char) {
            case 65://if A on ASCII make it int 10
                first_int = 10;
                break;
            case 66:
                first_int = 11;
                break;
            case 67:
                first_int = 12;
                break;
            case 68:
                first_int = 13;
                break;
            case 69:
                first_int = 14;
                break;
            case 70:
                first_int = 15;
                break;
            case 71:
                first_int = 16;
        }
    }
    else {
        first_int = Number(my_value);//used to convert Decimal numbers to int
    }
    return first_int;
}

function int_to_string(num)//changes an int value to a char value including 10-16
{
    var my_char;
    if(num >= 10)
    {
        switch (num) {
            case 10:
                my_char = 'A';//if value is 10 change to A
                break;
            case 11:
                my_char = 'B';
                break;
            case 12:
                my_char = 'C';
                break;
            case 13:
                my_char = 'D';
                break;
            case 14:
                my_char = 'E';
                break;
            case 15:
                my_char = 'F';
                break;
            case 16:
                my_char = 'G';
        }
    }
    else
    {
        my_char = num.toString();
    }
    return my_char;
}

function check_rules_max(first_temp, second_temp, third_temp, max_value_2, max_value_3, order)//first does not change while we check max of second
{
    if (second_temp != max_value_2)//check to see if it is still within bounds of id limit rule
    {
        var new_cave;
        //check second digit if max will work
        second_temp = max_value_2;//[zero_max]
        third_temp = 16 - second_temp - first_temp;//sum_rule
        if (third_temp > 0 && third_temp <= max_value_3)//id_limit_rule
        {
            new_cave = get_string_order(first_temp, second_temp, third_temp, order);//changes cave values we got back into correct order
            return new_cave;//return value of new cave 
        }
    }
    return "";//returns empty if cave breaks a rule
}
function check_rules_min(first_temp, second_temp, third_temp, max_value_3, order)//first does not change while we check min of second
{
    if (second_temp != 0) {
        var new_cave;
        //check second digit if max will work
        second_temp = 0;//[zero_max]
        third_temp = 16 - second_temp - first_temp;//sum_rule
        if (third_temp > 0 && third_temp <= max_value_3)//id_limit_rule
        {
            new_cave = get_string_order(first_temp, second_temp, third_temp, order);//changes cave values we got back into correct order
            return new_cave;//return value of new cave 
        }
    }
    return "";//returns empty if cave breaks a rule
}

function get_string_order(first_temp, second_temp, third_temp, order)
{
    var first_value = order.charAt(0);//get value of first char in order into ascii
    var second_value = order.charAt(1);
    var third_value = order.charAt(2);
    var first_int = Number(first_value);//change value of first char to decimal
    var second_int = Number(second_value);
    var third_int = Number(third_value);
    var new_cave;

    if(first_int == 1)//if first value of order is 1 then it is first number in the string for cave
    {
        new_cave = int_to_string(first_temp);
    }
    else if(second_int == 1)
    {
        new_cave = int_to_string(second_temp);
    }
    else
    {
        new_cave = int_to_string(third_temp);
    }

    if (first_int == 2) {//if first value of order is 2 then it is second number in the string for cave
        new_cave += int_to_string(first_temp);
    }
    else if (second_int == 2) {
        new_cave += int_to_string(second_temp);
    }
    else {
        new_cave += int_to_string(third_temp);
    }

    if (first_int == 3) {//if first value of order is 3 then it is third number in the string for cave
        new_cave += int_to_string(first_temp);
    }
    else if (second_int == 3) {
        new_cave += int_to_string(second_temp);
    }
    else {
        new_cave += int_to_string(third_temp);
    }
    return new_cave;
}

function new_node_search(rctx, all_caves, total_caves_explored, causeways)
{
    var curr_cave = all_caves[total_caves_explored];//gets string for cave you are currently in
    var adj_caves = [];//create an array for caves found
    var first_value = curr_cave.charCodeAt(0);//change first char to equivalent ascii value
    var second_value = curr_cave.charAt(1);//get second char in string to individual char value
    var third_value = curr_cave.charAt(2);
    var first_int = char_to_int(first_value, curr_cave.charAt(0));//change first char to int
    var second_int = Number(second_value);//change second char to unt
    var third_int = Number(third_value);
    var new_cave = "";
    //leave first same and check max and min of second
    new_cave = check_rules_max(first_int, second_int, third_int, max_2, max_3, "123");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0)//checks to see if returned empty string meaning not valid cave
    {
        adj_caves.push(new_cave);
    }
    new_cave = check_rules_min(first_int, second_int, third_int, max_3, "123");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0)//checks to see if returned empty string meaning not valid cave
    {
        adj_caves.push(new_cave);
    }
    //leave first same and check max and min of third
    new_cave = check_rules_max(first_int, third_int, second_int, max_3, max_2, "132");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0)//checks to see if returned empty string meaning not valid cave
    {
        adj_caves.push(new_cave);
    }
    new_cave = check_rules_min(first_int, third_int, second_int, max_2, "132");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0)//checks to see if returned empty string meaning not valid cave
    {
        adj_caves.push(new_cave);
    }
    //leave second same and check max and min of first
    new_cave = check_rules_max(second_int, first_int, third_int, max_1, max_3, "213");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0)//checks to see if returned empty string meaning not valid cave
    {
        adj_caves.push(new_cave);
    }
    new_cave = check_rules_min(second_int, first_int, third_int, max_3, "213");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0)//checks to see if returned empty string meaning not valid cave
    {
        adj_caves.push(new_cave);
    }
    //leave second same and check max and min of third
    new_cave = check_rules_max(second_int, third_int, first_int, max_3, max_1, "231");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0) {//checks to see if returned empty string meaning not valid cave
        adj_caves.push(new_cave);
    }
    new_cave = check_rules_min(second_int, third_int, first_int, max_1, "231");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0) {//checks to see if returned empty string meaning not valid cave
        adj_caves.push(new_cave);
    }
    //leave third same and check max and min of first
    new_cave = check_rules_max(third_int, first_int, second_int, max_1, max_2, "312");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0) {//checks to see if returned empty string meaning not valid cave
        adj_caves.push(new_cave);
    }
    new_cave = check_rules_min(third_int, first_int, second_int, max_2, "312");//checks rules and returns whether cave follows the rules on not
    if (new_cave.localeCompare("") != 0) {//checks to see if returned empty string meaning not valid cave
        adj_caves.push(new_cave);
    }
    //leave third same and check max and min of second
    new_cave = check_rules_max(third_int, second_int, first_int, max_2, max_1, "321");
    if (new_cave.localeCompare("") != 0) {//checks to see if returned empty string meaning not valid cave
        adj_caves.push(new_cave);
    }
    new_cave = check_rules_min(third_int, second_int, first_int, max_1, "321");
    if (new_cave.localeCompare("") != 0) {//checks to see if returned empty string meaning not valid cave
        adj_caves.push(new_cave);
    }
    var num_adj_caves = adj_caves.length;//total number of caves adj to curr cave that are valid
    highlight_curr_cave(rctx, total_caves_explored, all_caves[total_caves_explored]);//highlights current cave and makes previous cave white
    for (var i = 0; i < num_adj_caves; i++)//for loop to check if adj caves are equivalent to caves already found
    {
        
                var new_node = true;//assume cave is new
                for (j = 0; j < all_caves.length; j++) {//loop to check if new cave is in all_cave array
                    if (my_str_cmp(adj_caves[i], all_caves[j]) == 0) {//if node already exists then not a new cave
                        new_node = false;
                        if (my_str_cmp(adj_caves[i], all_caves[total_caves_explored]) != 0 && total_caves_explored > j) {//if curr cave is not equal to new cave since the
                                                                                                                         //way i found caves could create this problem
                            draw_causeway_prev(rctx, total_caves_explored, j, causeways.num_causeways_prev);//draw a new causeway on right side of boxes
                            causeways.num_causeways_prev = causeways.num_causeways_prev + 1;//increment number of causeways on right side of boxes
                        }
                    }
                }
                if (new_node == true) {//if cave is new
                    all_caves.push(adj_caves[i]);//push the adj cave onto all cave array
                    write_cave(context, all_caves[all_caves.length - 1], all_caves.length - 1, total_cave_explored, causeways.num_causeways_new);//draw new cave onto canvas and a causeway to new cave
                    causeways.num_causeways_new = causeways.num_causeways_new + 1;//increment number of causeways on left side of boxes
                }
    }
}

function write_first_cave(rctx, curr_cave, cave_to, cave_at, num_causeways_new) {//used for first cave only
    //var my_interval = setInterval(function () {
    rctx.save();
    rctx.strokeStyle = 'green';//set line color
    rctx.fillStyle = 'yellow';//color of numbers
    rctx.font = "16px Consolas";
    let width = rctx.canvas.width;//width of rctx
    let height = rctx.canvas.height;//height of rctx
    rctx.fillText(curr_cave, 490, 30 * cave_to + 50);//write new cave values in center of box
    rctx.beginPath();//create a box
    rctx.moveTo(485, 30 * cave_to + 30);
    rctx.lineTo(485, 30 * cave_to + 60);
    rctx.lineTo(520, 30 * cave_to + 60);
    rctx.lineTo(520, 30 * cave_to + 30);
    rctx.lineTo(485, 30 * cave_to + 30);
    rctx.stroke();
}

function write_cave(rctx, curr_cave, cave_to, cave_at, num_causeways_new)
{
        rctx.save();
        rctx.strokeStyle = 'white';//set line color
        rctx.fillStyle = 'yellow';//color of numbers
        rctx.font = "16px Consolas";
        let width = rctx.canvas.width;//width of rctx
        let height = rctx.canvas.height;//height of rctx
        rctx.fillText(curr_cave, 490, 30 * cave_to + 50);//write new cave values in center of box
    //draw rectangle around cave value
        rctx.beginPath();
        rctx.moveTo(485, 30 * cave_to + 30);
        rctx.lineTo(485, 30 * cave_to + 60);
        rctx.lineTo(520, 30 * cave_to + 60);
        rctx.lineTo(520, 30 * cave_to + 30);
        rctx.lineTo(485, 30 * cave_to + 30);
        rctx.stroke();
    //draw causeway depending on number already found
        rctx.beginPath();
        rctx.moveTo(485, 30 * cave_at + 40);
        rctx.lineTo(475 - (5 * num_causeways_new), 30 * cave_at + 40);
        rctx.lineTo(475 - (5 * num_causeways_new), 30 * cave_to + 50);
        rctx.lineTo(485, 30 * cave_to + 50);
        rctx.stroke();
    //draw arrow to correct value
        rctx.beginPath();
        rctx.moveTo(485, 30 * cave_to + 50);
        rctx.lineTo(480, 30 * cave_to + 45);
        rctx.lineTo(480, 30 * cave_to + 55);
        rctx.lineTo(485, 30 * cave_to + 50);
        rctx.stroke();
     
}

function draw_causeway_prev(rctx, cave_at, cave_to, num_causeways_prev)
{
        rctx.save();
        rctx.strokeStyle = 'white';//set line color
        rctx.fillStyle = 'yellow';//color of numbers
        rctx.font = "16px Consolas";
        let width = rctx.canvas.width;//width of rctx
        let height = rctx.canvas.height;//height of rctx
    //draw causeway on right side to correct cave
        rctx.beginPath();
        rctx.moveTo(520, 30 * cave_at + 40);
        rctx.lineTo(530 + (5 * num_causeways_prev), 30 * cave_at + 40);
        rctx.lineTo(530 + (5 * num_causeways_prev), 30 * cave_to + 50);
        rctx.lineTo(520, 30 * cave_to + 50);
        rctx.stroke();
    //draw arrow to show direction
        rctx.beginPath();
        rctx.moveTo(520, 30 * cave_to + 50);
        rctx.lineTo(525, 30 * cave_to + 45);
        rctx.lineTo(525, 30 * cave_to + 55);
        rctx.lineTo(520, 30 * cave_to + 50);
        rctx.stroke();
}

function highlight_curr_cave(rctx, total_caves_explored, curr_cave)
{
    if (curr_cave != "G00") {//checks to make sure it isnt first cave
        rctx.save();
        rctx.strokeStyle = 'green';//set line color
        rctx.fillStyle = 'yellow';//color of numbers
        rctx.font = "16px Consolas";
        let width = rctx.canvas.width;//width of rctx
        let height = rctx.canvas.height;//height of rctx
        //highlight box currently on
        rctx.beginPath();
        rctx.moveTo(485, 30 * total_caves_explored + 30);
        rctx.lineTo(485, 30 * total_caves_explored + 60);
        rctx.lineTo(520, 30 * total_caves_explored + 60);
        rctx.lineTo(520, 30 * total_caves_explored + 30);
        rctx.lineTo(485, 30 * total_caves_explored + 30);
        rctx.stroke();

        rctx.strokeStyle = 'white';//set line color
        //set box previously on back to white
        rctx.beginPath();
        rctx.moveTo(485, 30 * (total_caves_explored - 1) + 30);
        rctx.lineTo(485, 30 * (total_caves_explored - 1) + 60);
        rctx.lineTo(520, 30 * (total_caves_explored - 1) + 60);
        rctx.lineTo(520, 30 * (total_caves_explored - 1) + 30);
        rctx.lineTo(485, 30 * (total_caves_explored - 1) + 30);
        rctx.stroke();
    }
}
