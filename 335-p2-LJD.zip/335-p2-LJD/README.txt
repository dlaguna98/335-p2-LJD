Team Member: David Laguna
Team Name: LJD
Project Number: 2
Class Number: 335-05
Contents:2 folders, assets and HTML, a README.txt, and BigO.pdf
In assets there is a js file called draw_stuff.js and styles.css
In HTML there is an HTML file called Project_1.html
External requirements: A web browser
Setup and installation: none
Features: Calls a program that displays the blue cave system
for Asqwilanda caverns.
Bugs: Does not pause on every new causeway but on every new
cave found. 

Tested in Google Chrome
==============================================================

How to handle proj2.html

1. Main file is proj.html, a web page
2. Sibling folder is "assets"
3. Web page links to assets/styles.css
4. Web page has basic title, header, and text
5. After body it loads draw-stuff.js from assets
6. Then runs some Javascript commands

How to run the web page:
7. Drag and drop the proj2.html file into a web browser